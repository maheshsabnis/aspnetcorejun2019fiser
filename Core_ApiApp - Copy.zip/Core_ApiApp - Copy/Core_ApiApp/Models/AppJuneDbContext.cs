﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core_ApiApp.Models
{
    /// <summary>
    ///  The Data-Access Class
    /// </summary>
    public class AppJuneDbContext : DbContext
    {

       public DbSet<Category> Categories { get; set; }
       public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Must Read the Connection String from The application configuration
        /// and map with db
        /// DbContextOptions<T> class with establish connection with Database
        /// and map with tables
        /// </summary>
        public AppJuneDbContext(DbContextOptions<AppJuneDbContext> options) : base(options)
        {
        }

        /// <summary>
        /// The method will be used to create DB Tables based on Models
        /// defined as DbSet<T> in current class
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
