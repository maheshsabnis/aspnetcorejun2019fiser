﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Core_ApiApp.Models
{
    public class Product
    {
        [Key]
        public int ProductRowId { get; set; }
        [Required(ErrorMessage ="Product Id is Must")]
        public string ProductId { get; set; }
        [Required(ErrorMessage = "Product Name is Must")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Manufacturer is Must")]
        public string Manufacturer { get; set; }
        [Required(ErrorMessage = "Price is Must")]
        public int Price { get; set; }
        [Required(ErrorMessage = "Category Row Id is Must")]
        public int CategoryRowId { get; set; }
        public Category Category { get; set; }
    }
}
