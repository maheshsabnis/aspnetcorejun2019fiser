﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Core_ApiApp.Models
{
    public class Category
    {
        [Key] // Primary Identity Key
        public int CategoryRowId { get; set; }
        [Required(ErrorMessage ="Category Id is Required")]
        public string CategoryId { get; set; }
        [Required(ErrorMessage = "Category Name is Required")]
        public string CategoryName { get; set; }
        [Required(ErrorMessage = "Base Price is Required")]
      //  [NotNegative(ErrorMessage ="Base Price Cannot be -Ve")]
        public int BasePrice { get; set; }
    }

    public class NotNegativeAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (Convert.ToInt32(value) <= 0)
            {
                return false;
            }
            return true;
        }
    }
}
