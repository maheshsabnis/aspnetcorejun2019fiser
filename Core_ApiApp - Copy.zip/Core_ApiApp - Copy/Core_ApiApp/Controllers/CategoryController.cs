﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Core_ApiApp.Models;
using Core_ApiApp.Services;

namespace Core_ApiApp.Controllers
{
    // The RouteAttribute contains the URL Template to access WEB API 
    // [controller] --> Will be replaced by Controller Name
    // e.g. Category
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        IService<Category, int> catService;
        public CategoryController(IService<Category, int> catService)
        {
            this.catService = catService;
        }
        [HttpGet]
        public IActionResult Get()
        {
            var res = catService.GetAsync().Result;
            return Ok(res);
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var res = catService.GetAsync(id).Result;
            return Ok(res);
        }

        // public IActionResult Post([FromBody]Category category)
        //[HttpPost("{catId}/{catName}/{price}")]
        //public IActionResult Post(string catId, string catName, int price)
        [HttpPost]
        public IActionResult Post(Category category)
        {
            
                if (ModelState.IsValid)
                {
                    if (category.BasePrice <= 0) throw new Exception("Price cannot be -Ve");
                    var res = catService.CreateAsync(category).Result;
                    return Ok(res);
                }
                return BadRequest(ModelState);
            
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Category category)
        {
            var res = catService.UpdateAsync(id,category).Result;
            return Ok(res);
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var res = catService.DeleteAsync(id).Result;
            return Ok(res);
        }

    }
}