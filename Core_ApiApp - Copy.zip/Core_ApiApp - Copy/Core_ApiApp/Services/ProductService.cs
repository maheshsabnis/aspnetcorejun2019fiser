﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core_ApiApp.Models;
using Microsoft.EntityFrameworkCore;

namespace Core_ApiApp.Services
{
    public class ProductService : IService<Product, int>
    {
        AppJuneDbContext context;
        /// <summary>
        /// Inject the DAL in the Service Repository class
        /// </summary>
        /// <param name="context"></param>
        public ProductService(AppJuneDbContext context)
        {
            this.context = context;
        }

        public async Task<Product> CreateAsync(Product entity)
        {
            // add entity in cursor
            var res = await  context.Products.AddAsync(entity);
            // commit transactions
            await context.SaveChangesAsync();
            // return the newly created entity
            return res.Entity;
        }

        public async  Task<bool> DeleteAsync(int id)
        {
            // search the entity based on id
            var res = await context.Products.FindAsync(id);
            if (res != null)
            {
                // if record is available then delete it
                context.Products.Remove(res);
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public async Task<IEnumerable<Product>> GetAsync()
        {
            return  await context.Products.ToListAsync();
        }

        public async Task<Product> GetAsync(int id)
        {
            var res = await context.Products.FindAsync(id);
            return res;
        }

        public async Task<bool> UpdateAsync(int id, Product entity)
        {
            // search the entity based on id
            var res = await context.Products.FindAsync(id);
            if (res != null)
            {

                res.ProductId = entity.ProductId;
                res.ProductName = entity.ProductName;
                res.Manufacturer = entity.Manufacturer;
                res.Price = entity.Price;
                res.CategoryRowId = entity.CategoryRowId;
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}
