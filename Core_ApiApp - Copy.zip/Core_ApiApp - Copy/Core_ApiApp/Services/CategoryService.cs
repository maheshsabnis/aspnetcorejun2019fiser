﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core_ApiApp.Models;
using Microsoft.EntityFrameworkCore;

namespace Core_ApiApp.Services
{
    public class CategoryService : IService<Category, int>
    {
        AppJuneDbContext context;
        /// <summary>
        /// Inject the DAL in the Service Repository class
        /// </summary>
        /// <param name="context"></param>
        public CategoryService(AppJuneDbContext context)
        {
            this.context = context;
        }

        public async Task<Category> CreateAsync(Category entity)
        {
            // add entity in cursor
            var res = await  context.Categories.AddAsync(entity);
            // commit transactions
            await context.SaveChangesAsync();
            // return the newly created entity
            return res.Entity;
        }

        public async  Task<bool> DeleteAsync(int id)
        {
            // search the entity based on id
            var res = await context.Categories.FindAsync(id);
            if (res != null)
            {
                // if record is available then delete it
                context.Categories.Remove(res);
                await context.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public async Task<IEnumerable<Category>> GetAsync()
        {
            return  await context.Categories.ToListAsync();
        }

        public async Task<Category> GetAsync(int id)
        {
            var res = await context.Categories.FindAsync(id);
            return res;
        }

        public async Task<bool> UpdateAsync(int id, Category entity)
        {
            // search the entity based on id
            var res = await context.Categories.FindAsync(id);
            if (res != null)
            {

                res.CategoryId = entity.CategoryId;
                res.CategoryName = entity.CategoryName;
                res.BasePrice = entity.BasePrice;
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}
