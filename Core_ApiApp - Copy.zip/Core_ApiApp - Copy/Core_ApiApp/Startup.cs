﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Core_ApiApp.Models;
using Microsoft.EntityFrameworkCore;
using Core_ApiApp.Services;
using Core_ApiApp.CustomMiddleware;
using Swashbuckle.AspNetCore.Swagger;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Identity;

namespace Core_ApiApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // the database connection object using EF Core
            services.AddDbContext<AppJuneDbContext>((options) => {
                options.UseSqlServer(Configuration.GetConnectionString("AppConnection"));
            });


            services.AddDbContext<SecurityContext>((options) => {
                options.UseSqlServer(Configuration.GetConnectionString("SecurityContextConnection"));
            });


            // register the repository services in the DI COntainer
            services.AddTransient<IService<Category, int>, CategoryService>();
            services.AddTransient<IService<Product,int>,ProductService>();

            // Register the Identity
            services.AddAuthentication();
            services.AddDefaultIdentity<IdentityUser>();

            // defining the SwaggerDoc object for the current WEB API application
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", 
                    new Swashbuckle.AspNetCore.Swagger.Info
                    { Title = "My Secure API", Version = "v1" });
            });

            // The DefaultContractResolver() will be used to serialize 
            // model properties is as-it-is format i.e. Pascal-Case
            services.AddMvc()
                .AddJsonOptions(options => options.SerializerSettings.ContractResolver
              = new DefaultContractResolver())
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            // use thye Swagger Document service
            app.UseSwagger();

            // Swagger UI Middleware to Render UI with 
            // API Definition
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "My Secure API V1");
            });

            app.UseCustmoErrorHandlerMiddleware();
            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
