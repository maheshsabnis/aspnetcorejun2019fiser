﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core_ApiApp.CustomMiddleware
{
    /// <summary>
    /// The class will be used to serialize JSON Response to client when error occures
    /// </summary>
    public class ErrorResponse
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }

    /// <summary>
    /// The class that contains logic for Error Handling
    /// </summary>
    public class ErrorMiddleware
    {
        RequestDelegate request;
        public ErrorMiddleware(RequestDelegate request)
        {
            this.request = request;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                // if no error then continue with next middleware
                await request(context);
            }
            catch (Exception ex)
            {
                // else generate the error response
                HandleError(context, ex);
            }
        }
        /// <summary>
        /// Method that contains the logic for error handling and response
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ex"></param>
        private void HandleError(HttpContext context, Exception ex)
        {
            // set the error code
            context.Response.StatusCode = 500;

            // the error class to structure the error message

            var errorMessage = new ErrorResponse()
            {
                ErrorCode = context.Response.StatusCode,
                ErrorMessage = ex.Message
            };

            // JSON serialize the ErrorReponse Object
            var responseMessage = JsonConvert.SerializeObject(errorMessage);

            // write the response
            context.Response.WriteAsync(responseMessage);
        }
    }

    // create a Custom Middleware Extention class

    public static class CustomErrorMiddleware
    {
        // extension method
        public static void UseCustmoErrorHandlerMiddleware(this IApplicationBuilder builder)
        {
            // register the ErrorMiddleware class'
            builder.UseMiddleware<ErrorMiddleware>();
        }
    }
         


}
